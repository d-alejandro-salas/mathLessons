// temporal.js — Coloca cada archivo de files.zip en su lugar dentro del proyecto.
//
// Uso (desde la carpeta principal del proyecto, donde están package.json y app/):
//     node temporal.js              → lee ./files.zip
//     node temporal.js otro.zip     → lee otro zip
//
// No necesita instalar nada: lee el .zip con los módulos incluidos de Node.
// Antes de reemplazar, guarda una copia de cada archivo actual en .backup-temporal/<fecha>/.

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// nombre del archivo en el zip  →  ruta destino dentro del proyecto
const DESTINOS = {
  'Header.jsx': 'components/Header.jsx',
  'MobileNav.jsx': 'components/MobileNav.jsx',
};

const ROOT = process.cwd();
const ZIP = path.resolve(ROOT, process.argv[2] || 'files.zip');

function fail(msg) {
  console.error(`\n✖ ${msg}\n`);
  process.exit(1);
}

// ---------- lector mínimo de .zip (stored / deflate) ----------
function leerZip(buf) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('no parece un archivo .zip válido');

  const total = buf.readUInt16LE(eocd + 10);
  let p = buf.readUInt32LE(eocd + 16);
  const entradas = [];

  for (let n = 0; n < total; n++) {
    if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('directorio central dañado');
    const metodo = buf.readUInt16LE(p + 10);
    const compSize = buf.readUInt32LE(p + 20);
    const nameLen = buf.readUInt16LE(p + 28);
    const extraLen = buf.readUInt16LE(p + 30);
    const commentLen = buf.readUInt16LE(p + 32);
    const localOffset = buf.readUInt32LE(p + 42);
    const nombre = buf.toString('utf8', p + 46, p + 46 + nameLen);
    p += 46 + nameLen + extraLen + commentLen;

    if (nombre.endsWith('/')) continue; // carpeta

    const lNameLen = buf.readUInt16LE(localOffset + 26);
    const lExtraLen = buf.readUInt16LE(localOffset + 28);
    const inicio = localOffset + 30 + lNameLen + lExtraLen;
    const datos = buf.subarray(inicio, inicio + compSize);

    let contenido;
    if (metodo === 0) contenido = datos;
    else if (metodo === 8) contenido = zlib.inflateRawSync(datos);
    else throw new Error(`método de compresión no soportado (${metodo}) en ${nombre}`);

    entradas.push({ nombre, contenido });
  }
  return entradas;
}

// ---------- verificaciones ----------
if (!fs.existsSync(path.join(ROOT, 'package.json')) || !fs.existsSync(path.join(ROOT, 'app'))) {
  fail('Esta no parece la carpeta principal del proyecto (falta package.json o app/).\n  Copiá temporal.js y files.zip ahí y ejecutalo de nuevo.');
}
if (!fs.existsSync(ZIP)) {
  fail(`No encuentro ${path.basename(ZIP)} en ${ROOT}.\n  Ponelo en la carpeta principal o pasá la ruta: node temporal.js ruta/al.zip`);
}

let entradas;
try {
  entradas = leerZip(fs.readFileSync(ZIP));
} catch (e) {
  fail(`No pude leer el zip: ${e.message}`);
}

// ---------- copia de cada archivo ----------
const sello = new Date().toISOString().replace(/[:.]/g, '-');
const respaldo = path.join(ROOT, '.backup-temporal', sello);
const colocados = new Set();
const ignorados = [];
let hayRespaldo = false;

for (const { nombre, contenido } of entradas) {
  const base = path.basename(nombre); // sirve tanto si el zip trae carpetas como si no
  const destino = DESTINOS[base];

  if (!destino) { ignorados.push(nombre); continue; }

  const abs = path.join(ROOT, destino);
  const existia = fs.existsSync(abs);

  if (existia) {
    const copia = path.join(respaldo, destino);
    fs.mkdirSync(path.dirname(copia), { recursive: true });
    fs.copyFileSync(abs, copia);
    hayRespaldo = true;
  }

  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, contenido);
  colocados.add(base);
  console.log(`${existia ? '↻ reemplazado' : '＋ creado     '}  ${destino}`);
}

// ---------- resumen ----------
const faltan = Object.keys(DESTINOS).filter((b) => !colocados.has(b));

console.log(`\n✔ ${colocados.size} de ${Object.keys(DESTINOS).length} archivos colocados.`);
if (faltan.length) console.log(`⚠ No estaban en el zip: ${faltan.join(', ')}`);
if (ignorados.length) console.log(`ℹ Ignorados (no forman parte de este cambio): ${ignorados.join(', ')}`);
if (hayRespaldo) console.log(`🗂  Copia de los originales en: ${path.relative(ROOT, respaldo)}`);
console.log('\nSiguiente paso: reiniciá "npm run dev". Cuando verifiques que todo anda, podés borrar temporal.js, files.zip y .backup-temporal/.\n');

if (colocados.size === 0) process.exit(1);
